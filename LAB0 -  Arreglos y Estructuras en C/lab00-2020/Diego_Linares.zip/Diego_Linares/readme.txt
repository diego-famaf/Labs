
Ejercicio 1:
COMPILAR CON:
$ gcc -std=c99 max_min.c

EJECUTAR CON:
$ ./a.out

Ejercicio 2:
COMPILAR CON:
$ gcc -std=c99 tictactoe.c

EJECUTAR CON:
$ ./a.out


